package br.edu.fatecpg.approom.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import br.edu.fatecpg.approom.model.User

@Dao
interface UserDao {
    @Query("SELECT * FROM user_table")
    suspend fun getAll(): List<User>

    @Insert
    suspend fun insert(user: User)

    @Update
    suspend fun update(user: User)

    @Delete
    suspend fun delete(user: User)

    @Query("SELECT * FROM user_table WHERE uid = :userId")
    suspend fun getUserById(userId: Int): User?
}
