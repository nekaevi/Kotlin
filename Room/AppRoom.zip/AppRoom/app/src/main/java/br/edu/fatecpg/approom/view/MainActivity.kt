package br.edu.fatecpg.approom.view

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import br.edu.fatecpg.approom.R
import br.edu.fatecpg.approom.dao.UserDao
import br.edu.fatecpg.approom.database.AppDatabase
import br.edu.fatecpg.approom.databinding.ActivityMainBinding
import br.edu.fatecpg.approom.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var db: AppDatabase
    private lateinit var userDao: UserDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "database-app"
        ).fallbackToDestructiveMigration()
            .build()

        userDao = db.userDao()

        // Salvar usuário
        binding.btnSave.setOnClickListener {
            val firstName = binding.edtFname.text.toString()
            val email = binding.edtEmail.text.toString()
            val profilePicture = binding.edtProfilePicture.text.toString() // Campo para a URL ou caminho da foto
            val user = User(0, firstName, email, profilePicture)

            lifecycleScope.launch {
                userDao.insert(user)
                Toast.makeText(this@MainActivity, "Usuário salvo!", Toast.LENGTH_SHORT).show()
                binding.edtFname.setText("")
                binding.edtEmail.setText("")
                binding.edtProfilePicture.setText("") // Limpar campo de perfil
            }
        }

        // Listar usuários
        binding.btnList.setOnClickListener {
            lifecycleScope.launch {
                val list = withContext(Dispatchers.IO) {
                    userDao.getAll()
                }
                list.forEach { user ->
                    Log.d("USUÁRIO", "${user.uid} - ${user.firstName} - ${user.email} - ${user.profilePicture}")
                }
            }
        }
    }
}
